from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from App.models import Stuent, Grade


def index(request):
    return HttpResponse('Hello')


def get_student(request):
    student = Stuent.objects.all()
    print(student)
    context = {'students': student}
    return render(request, "getstudent.html", context)


def get_grade(requset):
    grade = Grade.objects.all()
    context = {"grades": grade}
    return render(requset, "getgrade.html", context)