from django.contrib import admin

# Register your models here.
from App.models import Grade
from App.models import Stuent

admin.site.register(Grade)
admin.site.register(Stuent)