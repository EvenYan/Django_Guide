from django.db import models

# Create your models here.


class Grade(models.Model):
    g_name = models.CharField(max_length=40)
    g_num = models.IntegerField(default=40)

    def __str__(self):
        return self.g_name

    class Meta:
        verbose_name = "班级"
        verbose_name_plural = "班级"


class Stuent(models.Model):
    s_name = models.CharField(max_length=40)
    s_age = models.IntegerField(default=18)
    s_sex = models.BooleanField(default=1)
    s_grade = models.ForeignKey(Grade)

    def __str__(self):
        return self.s_name

    class Meta:
        ordering = ["-id"]
        verbose_name = "学生"
        verbose_name_plural = "学生"


